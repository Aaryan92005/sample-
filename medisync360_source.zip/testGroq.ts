import dotenv from 'dotenv';
dotenv.config();
import { predictWithGroqAndDataset } from '../services/groqAiService';

async function test() {
  const query = 'I get a burning feeling in my chest right after eating big or spicy meals, especially when I lie down, and a sour taste in my mouth.';
  console.log('--- Testing query with Groq + Dataset ---');
  console.log(query);
  try {
    const res = await predictWithGroqAndDataset(query);
    console.log('--- PREDICTION RESULT ---');
    console.log(JSON.stringify(res, null, 2));
  } catch (err) {
    console.error('Error during prediction:', err);
  }
}

test();
