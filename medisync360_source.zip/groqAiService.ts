import Groq from 'groq-sdk';
import fs from 'fs';
import path from 'path';

export interface GroqDiagnosisResult {
  predictedCondition: string;
  recommendedSpecialist: string;
  urgencyLevel: string;
  description: string;
  confidence: number;
  matchedSymptoms: string[];
  alternativePossibilities: Array<{
    condition: string;
    confidence: number;
  }>;
  precautions: string[];
  dataSource: string;
  modelType: string;
}

let cachedMetadata: {
  symptoms: string[];
  diseases: string[];
  disease_descriptions: Record<string, string>;
  disease_precautions: Record<string, string[]>;
} | null = null;

const loadDatasetMetadata = () => {
  if (cachedMetadata) return cachedMetadata;
  try {
    const metaPath = path.join(__dirname, '../../ml_model/trained_model/metadata.json');
    if (fs.existsSync(metaPath)) {
      const data = JSON.parse(fs.readFileSync(metaPath, 'utf8'));
      cachedMetadata = {
        symptoms: data.symptoms || [],
        diseases: data.diseases || [],
        disease_descriptions: data.disease_descriptions || {},
        disease_precautions: data.disease_precautions || {},
      };
      return cachedMetadata;
    }
  } catch (err) {
    console.warn('Could not load trained_model metadata.json for Groq:', err);
  }
  return null;
};

export const predictWithGroqAndDataset = async (
  patientText: string
): Promise<GroqDiagnosisResult | null> => {
  const apiKey = process.env.GROQ_API_KEY;
  if (!apiKey || apiKey.trim() === '' || apiKey.startsWith('replace-')) {
    return null;
  }

  const meta = loadDatasetMetadata();
  if (!meta || !meta.diseases.length) {
    return null;
  }

  const groq = new Groq({ apiKey });

  const systemPrompt = `You are MediSync360's Chief Clinical Diagnostic AI.
Analyze patient symptoms and map them accurately.

DATASET CANONICAL DISEASES:
${JSON.stringify(meta.diseases)}

DATASET CANONICAL SYMPTOMS:
${JSON.stringify(meta.symptoms)}

CRITICAL VALIDATION & SAFETY RULES:
1. GIBBERISH / INVALID / NON-MEDICAL INPUT:
   If the user inputs random numbers (e.g. "123", "999"), keyboard smashes (e.g. "asdfgh"), greetings ("hi", "hello"), or text that contains NO actual clinical symptoms, you MUST return:
   {
     "is_valid_symptoms": false,
     "match_found": false,
     "predictedCondition": "No clear match found",
     "recommendedSpecialist": "General Practitioner",
     "urgencyLevel": "Low - Consult a doctor for proper evaluation",
     "confidence": 0,
     "matchedSymptoms": [],
     "alternativePossibilities": [],
     "description": "The input provided does not contain recognizable clinical symptoms. Please describe your symptoms in words (e.g., headache, fever, cough, chest pain)."
   }

2. DISEASES NOT IN OUR DATASET:
   Our medical platform strictly models ONLY the 41 CANONICAL DISEASES listed above.
   If the user's symptoms indicate a medical condition that is NOT one of our 41 canonical diseases (for example: Appendicitis, COVID-19, Strep Throat, Kidney Stones, Gallstones, Cancer, etc.), or if symptoms do not clearly point to any of our 41 conditions:
   DO NOT GUESS OR FORCE A WRONG DATASET DISEASE (e.g. do NOT guess Gastroenteritis for Appendicitis).
   Instead, you MUST return:
   {
     "is_valid_symptoms": true,
     "match_found": false,
     "predictedCondition": "No clear match found",
     "recommendedSpecialist": "General Practitioner",
     "urgencyLevel": "Medium - Consult a doctor for proper evaluation",
     "confidence": 0,
     "matchedSymptoms": ["extracted symptom 1", "extracted symptom 2"],
     "alternativePossibilities": [],
     "description": "Symptoms do not match conditions in our database. Please consult a healthcare professional for proper evaluation."
   }

3. VALID MEDICAL INPUT MATCHING OUR 41 DISEASES:
   When the symptoms match one of our 41 canonical diseases (e.g. GERD, Malaria, Dengue, Chicken pox, Migraine, Diabetes, Jaundice, etc.):
   Select the exact disease name from the list and return:
   {
     "is_valid_symptoms": true,
     "match_found": true,
     "predictedCondition": "Exact Disease Name from List",
     "recommendedSpecialist": "Medical Specialist",
     "urgencyLevel": "Emergency - Seek immediate care | High - See doctor within 24 hours | Medium - Schedule appointment soon | Low - Monitor symptoms",
     "confidence": 95,
     "matchedSymptoms": ["symptom1", "symptom2"],
     "alternativePossibilities": [
       { "condition": "Alternative Condition from List", "confidence": 25 }
     ]
   }`;

  const completion = await groq.chat.completions.create({
    messages: [
      { role: 'system', content: `${systemPrompt}\n\nYou must respond ONLY in strict valid JSON format.` },
      { role: 'user', content: `Patient Symptom Report:\n"${patientText}"\n\nProvide your diagnostic evaluation in JSON.` },
    ],
    model: 'openai/gpt-oss-120b',
    temperature: 0.1,
    response_format: { type: 'json_object' },
  });

  const rawContent = completion.choices[0]?.message?.content;
  if (!rawContent) return null;

  const parsed = JSON.parse(rawContent);

  if (parsed.is_valid_symptoms === false || parsed.match_found === false || parsed.confidence === 0 || parsed.predictedCondition === 'No clear match found') {
    return {
      predictedCondition: 'No clear match found',
      recommendedSpecialist: parsed.recommendedSpecialist || 'General Practitioner',
      urgencyLevel: parsed.urgencyLevel || 'Low - Consult a doctor for proper evaluation',
      description:
        parsed.description ||
        'Symptoms do not match conditions in our database. Please consult a healthcare professional for proper evaluation.',
      confidence: 0,
      matchedSymptoms: parsed.matchedSymptoms || [],
      alternativePossibilities: [],
      precautions: ['Consult a qualified healthcare professional', 'Monitor symptoms closely for any worsening'],
      dataSource: 'MediSync Grounded Clinical Engine',
      modelType: 'Dataset Strict Boundary Filter',
    };
  }

  const disease = parsed.predictedCondition || 'General Consultation';
  const desc =
    meta.disease_descriptions[disease] ||
    parsed.description ||
    `Clinical manifestation matching profile for ${disease}.`;
  const precautions = meta.disease_precautions[disease] || [
    'Consult a certified healthcare professional',
    'Follow prescribed medical regimen',
  ];

  return {
    predictedCondition: disease,
    recommendedSpecialist: parsed.recommendedSpecialist || 'General Practitioner',
    urgencyLevel: parsed.urgencyLevel || 'Medium - Schedule appointment soon',
    description: desc,
    confidence: Number(parsed.confidence) || 90,
    matchedSymptoms: parsed.matchedSymptoms || [patientText],
    alternativePossibilities: parsed.alternativePossibilities || [],
    precautions,
    dataSource: 'Groq Llama-3.3 (Grounded on MediSync Kaggle Dataset)',
    modelType: 'Hybrid LLM + Dataset RAG Engine',
  };
};
